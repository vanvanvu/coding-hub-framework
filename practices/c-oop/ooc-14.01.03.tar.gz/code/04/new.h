#ifndef	NEW_H
#define	NEW_H

void * new (const void * class, ...);
void delete (void * item);
void draw (const void * self);

#endif
